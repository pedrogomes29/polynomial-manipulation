# PolynomialManipulation
Manipulating polynomials in haskell
